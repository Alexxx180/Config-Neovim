vim.o.termguicolors = true
vim.cmd [[ colorscheme dracula ]]
