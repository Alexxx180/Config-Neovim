require("nvim-web-devicons").refresh()
