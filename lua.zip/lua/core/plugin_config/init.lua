require("core.plugin_config.schema")
require("core.plugin_config.nvim-tree")
require("core.plugin_config.lualine")
