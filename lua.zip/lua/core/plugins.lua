﻿local function bootstrap_pckr()
    local pckr_path = vim.fn.stdpath("data") .. "/pckr/pckr.nvim"

    if not vim.loop.fs_stat(pckr_path) then
        vim.fn.system({
            'git',
            'clone',
            '--filter=blob:none',
            'https://github.com/lewis6991/pckr.nvim',
            pckr_path
        })
    end

    vim.opt.rtp:prepend(pckr_path)
end

bootstrap_pckr()

return require('pckr').add{
    -- fast commentary :1,10Commentary
    'tpope/vim-commentary';

    -- color scheme
    'dracula/vim';

    { 'catppuccin/nvim', as = 'catppuccin' };

    -- icons, status, highlight, tree
    'nvim-lualine/lualine.nvim';
    'nvim-treesitter/nvim-treesitter';
    'nvim-tree/nvim-tree.lua';
    'nvim-tree/nvim-web-devicons';


    -- testing
    'vim-test/vim-test';

    -- :Git commands and markings
    'lewis6991/gitsigns.nvim';
    'tpope/vim-fugitive';

    -- surrounding
    'tpope/vim-surround';

    -- language completion
    'hrsh7th/nvim-cmp';
    'hrsh7th/cmp-nvim-lsp';
    'L3MON4D3/LuaSnip';
    'saadparwaiz1/cmp_luasnip';
    'rafamadriz/friendly-snippets';

    -- package management
    {
        'williamboman/mason.nvim',
        'williamboman/mason-lspconfig.nvim',
        'neovim/nvim-lspconfig',
    };

    -- ultimate file explorer
    'stevearc/oil.nvim';

    -- file finder
    { 'nvim-telescope/telescope.nvim',
	    tag = '0.1.0',
	    requires = {'nvim-lua/plenary.nvim'}
    };
}
