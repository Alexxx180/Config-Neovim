require("core.options")
require("core.plugins")
require("core.plugin_config")
